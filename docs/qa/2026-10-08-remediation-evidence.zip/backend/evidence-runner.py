import json
import sys
from pathlib import Path
import pytest
class Evidence:
    def __init__(self): self.reports=[]
    def pytest_runtest_logreport(self, report):
        self.reports.append({"nodeid": report.nodeid, "when": report.when, "outcome": report.outcome, "seconds": report.duration})
        if report.failed:
            print("\nIMMEDIATE FAILURE:", report.nodeid, "\n", report.longrepr, flush=True)
    def pytest_sessionfinish(self, session, exitstatus):
        Path("/tmp/cernal-qa-20261008/final-test-cases.json").write_text(json.dumps({"exitstatus":int(exitstatus),"reports":self.reports},indent=2))
raise SystemExit(pytest.main(sys.argv[1:],plugins=[Evidence()]))
