"""Read-only scientific QA probes. Writes test artifacts only under var/audit-2026-10-08."""
from pathlib import Path
import dataclasses
import gc
import hashlib
import json
import weakref
from collections import Counter

from engine.client import LocalEngine
from engine.contract import JobRequest, SCHEMA_VERSION
from engine.domain import BooleanExpression, CircuitCandidate, ConfusionMatrix, Constraints, DesiredOutcome, Host, LogicGraph, LogicOperator, SegmentKind, TriggerCandidate, TriggerSet
from engine.gates.tools.folding import FoldEngine
from engine.inputs import parse_dge_table
from engine.pipeline import build_tools
from engine.scoring.normalize import normalize_value, failed_filter
from engine.scoring.profiles import DEFAULT_V1
from engine.stages.genes import GeneSelector
from engine.stages.plasmids import to_genbank
from engine.stages.switches import SwitchValidator
from engine.stages.motifs import MotifScreener

ROOT=Path(__file__).resolve().parent
CLEAN="AACUUGUUGGCCCAGUGUGAAUCGCUUAAGGGUUAA"

def req(name, **kw):
    d=dict(schema_version=SCHEMA_VERSION,run_id=name,idempotency_key=name,input_mode="direct",trigger_sequence=CLEAN,input_path="",input_checksum="",organism="ecoli",params={},gate_families=["toehold"],scoring_profile="default",seed=7,output_dir=str(ROOT/name))
    d.update(kw)
    return JobRequest(**d)

result={}
base=req("probe-base")
tools=build_tools(base,Host.ECOLI)
family=tools["families"][0]
t=TriggerCandidate("trig-a","gene-a","A",CLEAN,0,0.8,0.7,0.0,40.0,log2_fold_change=3.0)
t2=dataclasses.replace(t,trigger_id="trig-b",gene_id="gene-b",symbol="B",log2_fold_change=-3.0)
d1=next(family.generate_designs(TriggerSet(activators=(t,)),Constraints()))
d2=next(family.generate_designs(TriggerSet(activators=(t2,)),Constraints()))
graph=LogicGraph((),LogicOperator.AND,LogicOperator.AND,False,"gfp","")
circuit=CircuitCandidate("probe-circuit",BooleanExpression(LogicOperator.AND,("gene-a","gene-b")),graph,(d1,d2),ConfusionMatrix(0,0,0,0),"gfp")
builder=tools["plasmid_builder"]
and_plasmid=builder.build(circuit,DesiredOutcome.GFP)
or_plasmid=builder.build(dataclasses.replace(circuit,expression=BooleanExpression(LogicOperator.OR,("gene-a","gene-b"))),DesiredOutcome.GFP)
not_plasmid=builder.build(dataclasses.replace(circuit,expression=BooleanExpression(LogicOperator.NOT,("gene-a",))),DesiredOutcome.GFP)
result["physical_logic"]={"and_or_not_identical_sequence":and_plasmid.plasmid.sequence==or_plasmid.plasmid.sequence==not_plasmid.plasmid.sequence,"segment_kinds":[s.kind.value for s in and_plasmid.plasmid.segments],"violations":and_plasmid.violations,"no_backbone_genbank_is_circular":b"circular" in to_genbank(and_plasmid).splitlines()[0]}
validator=SwitchValidator(tools["folder"],tools["screener"],tools["translation"],tools["constraints"])
bogus=dataclasses.replace(d1,dot_bracket="unbalanced bogus intended structure")
result["structure_validation"]={"generated_passes":validator.validate(d1).ok,"bogus_target_structure_passes":validator.validate(bogus).ok}
forbidden_tools=build_tools(req("forbidden",params={"constraints":{"forbidden_motifs":["AACU"]}}),Host.ECOLI)
result["forbidden_motifs"]={"requested":list(forbidden_tools["constraints"].forbidden_motifs),"screener_extra":forbidden_tools["screener"].extra,"violation_count":len(forbidden_tools["screener"].violations(CLEAN))}
path=ROOT/"downregulated.csv"
path.write_text("gene_id,gene_symbol,log2fc,padj\nb3908,sodA,-3.2,0.001\nb0033,carA,-2.8,0.002\n")
down=LocalEngine().run(req("downregulated-run",input_mode="de",trigger_sequence="",input_path=str(path),input_checksum=hashlib.sha256(path.read_bytes()).hexdigest()),lambda *a:True)
accepted=[c for c in down.candidates if not c.is_rejected]
singles=[c for c in accepted if not c.design.get("component_switches")]
multi=[c for c in accepted if c.design.get("component_switches")]
result["negative_de"]={"status":down.status,"total":len(down.candidates),"accepted":len(accepted),"single_example":{k:getattr(singles[0],k) for k in ("logic_type","summary")} if singles else None,"single_logic_graph":singles[0].design["logic_graph"] if singles else None,"single_separation":next((m.raw_value for m in singles[0].metrics if m.name=="state_separation"),None) if singles else None,"multi_logic":[c.logic_type for c in multi],"multi_component_families":[c.gate_family for c in multi],"artifact_kinds":dict(Counter(a.kind for a in down.artifacts)),"warnings":down.warnings}
arthritis=Path("src/apps/expression/catalog/human/E-GEOD-103501__g3_g1.csv")
rows=parse_dge_table(arthritis.read_bytes(),arthritis.name).rows
warn=[]
plan=GeneSelector(Constraints(),MotifScreener())._significance_plan(list(rows),warn.append)
result["arthritis_fdr"]={"rows":len(rows),"adjusted_p_count":sum(r.p_adj is not None for r in rows),"raw_p_count":sum(r.p_value is not None for r in rows),"chosen_plan":plan.mode,"warnings":warn}
parsed=parse_dge_table(b"gene_id,log2fc,padj\ngene-a,Infinity,-0.2\ngene-b,NAN,0.01\n")
result["numeric_validation"]={"parsed_nonfinite_rows":len(parsed.rows),"value_strings":[(str(r.log2_fold_change),str(r.p_adj)) for r in parsed.rows],"nan_leakage_filter_breach":str(failed_filter({"predicted_leakage":float("nan")},DEFAULT_V1)),"nan_normalized":str(normalize_value(float("nan"),DEFAULT_V1.spec("predicted_leakage")))}
folder=FoldEngine(cache_size=1)
folder.mfe("ACGUACGU")
folder.mfe("UGCAUGCA")
ref=weakref.ref(folder)
del folder
gc.collect()
result["cache_lifetime"]={"folder_alive_after_del_and_gc":ref() is not None,"cache_info":str(FoldEngine.mfe.cache_info()),"declared_capacity":1}
(ROOT/"engine-probes.json").write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
