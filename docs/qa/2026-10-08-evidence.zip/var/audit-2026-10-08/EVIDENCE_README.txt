CERNAL QA evidence, 8 October 2026

Companion report: docs/SOFTWARE_STATUS_REVIEW_2026-10-08.md.
Extract from the repository root to restore var/audit-2026-10-08/ paths.
Source and installed-environment versions are described in the report.
source-snapshot.json hashes the relevant working-tree source and lockfiles.

These are diagnostic probes of the BEFORE state. In particular, the27 platform
probe tests assert observed defects; passing them is not acceptance of correctness.
Turn confirmed bugs into desired-behavior regression tests during fixes.
Browser probes use real compiled frontend assets with ALL HTTP responses mocked.
Python live-server tests use an isolated test database and ephemeral credentials.
All cern_live_ tokens were redacted from retained logs. No user database, uploads,
media, generated construct directories or installed dependencies are included.

The ordinary1655-test suite passed. Python client conformance failed1/4 due to
a stale zero-candidate biological fixture. Ruff formatting failed1 existing file.
Do not interpret these logs as biological or operational release certification.
