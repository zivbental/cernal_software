// Isolated browser audit. Application build is real; every API response is mocked.
// No requests reach a running server, no existing data is modified.
import { chromium } from '../../frontend/node_modules/playwright/index.mjs';
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';

const repo = resolve(import.meta.dirname, '../..');
const capabilities = JSON.parse(readFileSync(resolve(import.meta.dirname, 'product-capabilities.json')));
const browser = await chromium.launch({headless: true});
const observations = [];
const candidate = (i) => ({id:`candidate-${i}`, engine_ref:`circ-${i}`, rank:i+1, overall_score:0.6,
  gate_family:'toehold', logic_type:'IDENTITY', is_rejected:false, rejection_reason:'', summary:'Audit candidate', output:'GFP', metrics:[],
  design:{switch_sequence:'ACGU',plasmid_segments:[],logic_graph:{genes:[],output:'GFP',caption:''}}, warnings:[]});
let mode = 'normal';
const requests = [];
const context = await browser.newContext();
await context.route('**/*', async route => {
  const req=route.request(), url=new URL(req.url()), path=url.pathname;
  if (path.startsWith('/api/')) {
    requests.push({path,search:url.search,method:req.method()});
    let body;
    if (path==='/api/auth/me') body={id:1,username:'audit',email:'audit@example.test',is_staff:false};
    else if (path==='/api/version') body={...capabilities,app_version:'audit',api_schema_version:'1',engine_schema_version:'1',engine:'LocalEngine',reviewer_login_enabled:false};
    else if (path==='/api/auth/csrf') body={ok:true};
    else if (path==='/api/datasets'||path==='/api/example-datasets'||path.startsWith('/api/public-datasets/')) body=[];
    else if (path==='/api/reference-genes/resolve') body={gene_id:'ENSG_AUDIT',gene_symbol:'AUDIT',sequence:'ACGU'.repeat(100),transcript_id:'ENST_AUDIT',selection_method:'canonical'};
    else if (path==='/api/runs'&&req.method()==='POST') return route.abort('failed');
    else if (path==='/api/runs'&&mode==='dashboard-error') return route.fulfill({status:500,contentType:'application/json',body:JSON.stringify({error:{code:'audit',message:'Simulated database failure'}})});
    else if (path==='/api/runs') body=[];
    else if (path.match(/^\/api\/runs\/[^/]+$/)) body={id:'audit',status:'COMPLETED',stage:'Completed',progress_pct:100,warnings:['UNIQUE_AUDIT_WARNING: sequence exports held'],counts:{candidates:mode==='empty'?0:7907,artifacts:0}};
    else if(path.endsWith('/candidates')) body={items:mode==='empty'?[]:Array.from({length:200},(_,i)=>candidate(i)),total:mode==='empty'?0:7907,limit:200,offset:0};
    else if(path.startsWith('/api/candidates/')) body=candidate(Number(path.split('-').at(-1))||0);
    else if(path.endsWith('/artifacts')) body=[];
    else body={};
    return route.fulfill({status:200,contentType:'application/json',body:JSON.stringify(body)});
  }
  if(path.startsWith('/static/app/')) {
    try {return route.fulfill({path:resolve(repo,'src/static/app',path.slice('/static/app/'.length))});}
    catch {return route.fulfill({status:404,body:''});}
  }
  if(path.startsWith('/assets/')) return route.fulfill({status:404,body:''});
  return route.fulfill({status:200,contentType:'text/html',body:readFileSync(resolve(repo,'src/static/app/index.html'))});
});
const page=await context.newPage();
page.on('pageerror', e=>observations.push({kind:'pageerror',message:e.message}));
const go=async path=>{await page.goto('https://cernal-audit.local'+path); await page.waitForTimeout(250);};
const compile=()=>page.getByRole('button',{name:'Compile & Optimize'});
try {
  await go('/compile');
  await compile().waitFor();
  observations.push({probe:'empty wizard correctly blocked',disabled:await compile().isDisabled()});
  await page.getByRole('button',{name:'Direct Trigger mRNA'}).click();
  await page.locator('textarea').first().fill('ACGU'.repeat(10));
  observations.push({probe:'direct input enables compile',enabled:await compile().isEnabled()});
  await page.getByRole('button',{name:/^GFP /}).click();
  await page.getByRole('button',{name:/^mCherry /}).click();
  observations.push({probe:'missing mCherry payload selectable and compile enabled',enabled:await compile().isEnabled()});
  await page.getByRole('button',{name:/^AND Toehold /}).click();
  observations.push({probe:'unbuilt AND family selectable and compile enabled',enabled:await compile().isEnabled()});
  await page.getByRole('button',{name:'Human',exact:true}).click();
  await page.getByRole('button',{name:/^Prokaryotic Toehold /}).click();
  observations.push({probe:'Human host with prokaryotic-only family compile enabled',enabled:await compile().isEnabled()});
  await page.locator('textarea').first().fill('>ACTG header\nACGUNNNNACGU');
  observations.push({probe:'pasted FASTA header and ambiguous bases silently transformed',value:await page.locator('textarea').first().inputValue()});
  await page.getByRole('button',{name:'Specific Gene',exact:true}).click();
  await page.getByRole('textbox',{name:'Gene ID or symbol'}).fill('AUDIT');
  await page.getByRole('button',{name:'Resolve reference transcript'}).click();
  await page.getByRole('status').waitFor();
  observations.push({probe:'mocked resolved gene enables compile',enabled:await compile().isEnabled(),stalePasteInstruction:await page.getByText('Record it here, then paste its sequence.',{exact:false}).count()});
  await page.getByRole('textbox',{name:'Gene ID or symbol'}).fill('EDITED');
  observations.push({probe:'editing resolved gene correctly invalidates compile',disabled:await compile().isDisabled()});
  await go('/compile');
  await page.getByRole('button',{name:/C\. acnes/}).first().click();
  observations.push({probe:'empty Cacnes catalog has explicit no-data message',hasMessage:/no (public|curated|datasets|experiments)/i.test(await page.locator('body').innerText())});
  await go('/runs/audit');
  await page.getByText('200 candidates returned. 200 shown after filters.').waitFor();
  observations.push({probe:'7907-candidate server result reduced to first 200 without count/paging',fullTotalVisible:(await page.locator('body').innerText()).includes('7907')||(await page.locator('body').innerText()).includes('7,907'),countText:await page.getByText('200 candidates returned. 200 shown after filters.').innerText(),warningVisible:(await page.locator('body').innerText()).includes('UNIQUE_AUDIT_WARNING')});
  mode='empty'; await go('/runs/empty');
  await page.getByText('No candidates match these filters. Loosen them to see more.').waitFor();
  observations.push({probe:'zero completed candidates retains endless detail loading spinner',spinnerCount:await page.locator('.animate-spin').count()});
  mode='dashboard-error'; await go('/dashboard'); await page.waitForTimeout(1800);
  observations.push({probe:'dashboard server error represented as no circuits',noCircuitsVisible:await page.getByText('No circuits yet',{exact:true}).count(),errorVisible:(await page.locator('body').innerText()).includes('Simulated database failure')});
  mode='normal'; await go('/compile');
  await page.getByRole('button',{name:'Direct Trigger mRNA'}).click();
  await page.locator('textarea').first().fill('ACGU'.repeat(10));
  await compile().click(); await page.waitForTimeout(200);
  observations.push({probe:'network failure on submission has readable alert',alerts:await page.getByRole('alert').allTextContents()});
  writeFileSync(resolve(import.meta.dirname,'product-browser-probes.json'),JSON.stringify({api:'mocked; real built UI',observations,requests},null,2));
  console.log(JSON.stringify(observations,null,2));
} finally {await browser.close();}
