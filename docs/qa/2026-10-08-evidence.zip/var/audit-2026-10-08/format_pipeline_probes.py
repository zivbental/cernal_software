"""Real pipeline execution for every advertised table format and host."""
import hashlib
import io
import json
from pathlib import Path
from openpyxl import Workbook
from engine.client import LocalEngine
from engine.contract import JobRequest, SCHEMA_VERSION

OUT = Path(__file__).resolve().parent
genes = {"ecoli": "b0005", "human": "ENSG00000201966", "yeast": "YDR281C", "c_acnes": "F6X01_RS12590"}
records = []
for host, gene in genes.items():
    for suffix in ("csv", "tsv", "txt", "xlsx"):
        path = OUT / "format-matrix" / f"{host}.{suffix}"
        path.parent.mkdir(exist_ok=True)
        if suffix == "xlsx":
            workbook = Workbook()
            workbook.active.append(["gene_id", "log2fc", "padj"])
            workbook.active.append([gene, 3.2, 0.001])
            stream = io.BytesIO()
            workbook.save(stream)
            raw = stream.getvalue()
        else:
            sep = "," if suffix == "csv" else "\t"
            raw = f"gene_id{sep}log2fc{sep}padj\n{gene}{sep}3.2{sep}0.001\n".encode()
        path.write_bytes(raw)
        request = JobRequest(schema_version=SCHEMA_VERSION, run_id="audit-format", idempotency_key="audit-format",
            input_mode="de", input_path=str(path), input_checksum=hashlib.sha256(raw).hexdigest(),
            trigger_sequence="", organism=host, params={}, gate_families=["toehold"], scoring_profile="default",
            seed=7, output_dir=str(path.parent / f"out-{host}-{suffix}"))
        progress = []
        result = LocalEngine().run(request, lambda pct, stage: progress.append((pct, stage)) or True)
        record = {"host": host, "format": suffix, "status": result.status,
            "candidates": len(result.candidates), "accepted": len(result.accepted),
            "progress_monotonic": [p[0] for p in progress] == sorted(p[0] for p in progress),
            "final_progress": progress[-1], "error": result.error}
        records.append(record)
        print(json.dumps(record), flush=True)
(OUT / "format-pipeline-probes.json").write_text(json.dumps(records, indent=2) + "\n")
