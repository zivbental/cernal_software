"""Read-only product audit: these assertions reproduce existing failures, not desired behavior."""
import csv
import io
import json
from pathlib import Path
from unittest.mock import patch

import pytest
from django.contrib.auth import get_user_model
from django.core.files.base import ContentFile
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import Client

from apps.accounts.services import issue_api_key
from apps.analyses.models import AnalysisRun, RunStatus
from apps.analyses.services import execute_run, submit_run, cancel_run, _transition
from apps.datasets.services import create_dataset, delete_dataset, preview_expression_rows, validate_expression_file
from apps.results.models import Candidate, CandidateMetric, Artifact
from apps.results.services import build_candidates_csv, import_job_result
from engine.contract import JobResult, ArtifactRef

pytestmark = pytest.mark.django_db

@pytest.fixture
def users(settings, tmp_path):
    settings.MEDIA_ROOT = tmp_path / 'media'
    a = get_user_model().objects.create_user('owner', password='audit-pass')
    b = get_user_model().objects.create_user('other', password='audit-pass')
    return a,b

def make_run(owner, **kwargs):
    defaults = dict(created_by=owner, input_mode='direct', trigger_sequence='ACGU'*10,
                    organism='ecoli', status=RunStatus.QUEUED, idempotency_key='private-key')
    defaults.update(kwargs)
    return AnalysisRun.objects.create(**defaults)

def post(client, path, body, **headers):
    return client.post(path, json.dumps(body), content_type='application/json', **headers)

def test_cross_owner_idempotency_discloses_original_submission(users):
    a,b=users
    victim=make_run(a, params_snapshot={'notes':'private patient research'})
    c=Client(); c.force_login(b)
    response=post(c, '/api/runs', {'input_mode':'direct', 'trigger_sequence':'ACGU'*8,
                   'idempotency_key':'private-key'})
    assert response.status_code == 202
    assert response.json()['id']==str(victim.id)
    assert response.json()['params_snapshot']['notes']=='private patient research'
    print('CROSS_OWNER_IDEMPOTENCY', response.status_code, response.json()['params_snapshot'])

def test_existing_privileged_reviewer_account_is_returned(users, settings):
    settings.REVIEWER_LOGIN_ENABLED=True
    get_user_model().objects.create_superuser('reviewer', password='audit-pass')
    c=Client(); response=post(c,'/api/auth/reviewer-login', {})
    assert response.status_code==200 and response.json()['is_staff'] is True
    print('REVIEWER_EXISTING_STAFF', response.json()['is_staff'])

def test_empty_scope_key_can_read_and_read_key_can_upload(users):
    a,b=users
    run=make_run(a)
    _,empty=issue_api_key(owner=a,label='empty',scopes=())
    c=Client(); assert c.get(f'/api/runs/{run.id}',HTTP_X_API_KEY=empty).status_code==200
    _,read=issue_api_key(owner=a,label='read',scopes=('read',))
    response=c.post('/api/datasets', {'file':SimpleUploadedFile('t.csv',b'gene_id,log2fc\nb0005,3\n')},HTTP_X_API_KEY=read)
    assert response.status_code==201
    print('SCOPES_EMPTY_READ_200_READ_UPLOAD',response.status_code)

def test_idempotent_retry_blocked_at_quota(users):
    a,b=users
    make_run(a)
    _,key=issue_api_key(owner=a,label='quota',max_concurrent_runs=1)
    response=post(Client(),'/api/runs',{'input_mode':'direct','trigger_sequence':'ACGU'*8,'idempotency_key':'private-key'},HTTP_X_API_KEY=key)
    assert response.status_code==429
    print('IDEMPOTENT_RETRY_QUOTA',response.status_code)

def test_worker_crash_running_row_not_recovered(users):
    run=make_run(users[0], status=RunStatus.RUNNING)
    execute_run(str(run.id));run.refresh_from_db()
    assert run.status==RunStatus.RUNNING
    print('REDELIVERED_RUNNING_STATUS',run.status)

def test_stale_start_can_overwrite_terminal_cancellation(users):
    run=make_run(users[0]); stale=AnalysisRun.objects.get(pk=run.pk)
    cancel_run(run)
    _transition(stale,RunStatus.RUNNING,stage='Starting')
    run.refresh_from_db(); assert run.status==RunStatus.RUNNING and run.finished_at is not None
    print('STALE_START',run.status,'HAS_FINISHED_TIMESTAMP',run.finished_at is not None)

def test_zero_metrics_export_as_missing(users):
    run=make_run(users[0]); candidate=Candidate.objects.create(run=run,engine_ref='zero',rank=1,overall_score=0.0,gate_family='toehold',logic_type='SINGLE')
    CandidateMetric.objects.create(candidate=candidate,name='predicted_leakage',raw_value=0.0,normalized_value=0.0,weight=1,direction='LOWER_BETTER')
    row=next(csv.DictReader(io.StringIO(build_candidates_csv(run))))
    assert row['predicted_leakage_raw']=='' and row['predicted_leakage_normalized']==''
    print('CSV_ZERO',row)

def test_dataset_delete_leaves_file(users):
    d=create_dataset(uploaded_file=SimpleUploadedFile('a.csv',b'gene_id,log2fc\nb0005,3\n'),user=users[0]); path=Path(d.file.path)
    delete_dataset(d)
    assert path.exists()
    print('DELETED_DATASET_FILE_STILL_EXISTS',path.exists())

def test_alias_headers_whitespace_bypass_numeric_validation(users):
    f=SimpleUploadedFile('a.csv',b' gene_id , log2fc \nb0005,not-number\n')
    report=validate_expression_file(f)
    assert not report['errors']
    print('INVALID_NUMERIC_WHITESPACE_HEADERS',report)

def test_extra_csv_cell_currently_accepted(users):
    c=Client(); c.force_login(users[0])
    # Duplicate numeric columns remap list may exercise malformed dict row handling.
    response=c.post('/api/datasets',{'file':SimpleUploadedFile('a.csv',b'gene_id,log2fc\nb0005,3,extra\n')})
    print('EXTRA_CELL_UPLOAD_STATUS',response.status_code)

def test_preview_uses_display_name_as_file_format(users):
    import openpyxl
    wb=openpyxl.Workbook();ws=wb.active;ws.append(['gene_id','log2fc']);ws.append(['b0005',3]);s=io.BytesIO();wb.save(s)
    d=create_dataset(uploaded_file=SimpleUploadedFile('table.xlsx',s.getvalue()),user=users[0],name='my study.csv')
    with pytest.raises(Exception,match='Excel workbook'):
        preview_expression_rows(d)
    print('PREVIEW_DISPLAY_NAME_FAILURE',d.name)

def test_malformed_scoring_produces_500(users):
    c=Client();c.force_login(users[0])
    response=post(c,'/api/runs',{'input_mode':'direct','trigger_sequence':'ACGU'*8,'params':{'scoring':{'weights':{'gc_content':'bad'}}}})
    assert response.status_code==500
    print('BAD_WEIGHT_STATUS',response.status_code)

def test_dry_run_accepts_invalid_sequence_and_budget(users):
    c=Client();c.force_login(users[0])
    response=post(c,'/api/design?dry_run=true',{'trigger_sequence':'not RNA','budget':{'max_designs':0,'max_runtime_seconds':0}})
    assert response.status_code==200 and response.json()['budget_ok'] is True
    print('DRY_RUN_INVALID',response.json())

def test_artifact_manifest_traverses_outside_output_directory(users,tmp_path):
    outside=tmp_path/'outside.txt';outside.write_text('outside output directory')
    out=tmp_path/'output';out.mkdir()
    run=make_run(users[0])
    result=JobResult(schema_version='wrong-schema',engine_version='audit',status='succeeded',params={'wrong':'params'},artifacts=[ArtifactRef(kind='report',path='../outside.txt',media_type='text/plain',checksum_sha256='')])
    summary=import_job_result(run,result,out)
    copied=Artifact.objects.get(run=run,kind='report')
    assert copied.file.read()==b'outside output directory'
    print('TRAVERSAL_ARTIFACT_IMPORTED',summary.artifacts)

def test_xlsx_active_sheet_differs_between_platform_and_engine(users):
    import openpyxl
    from engine.inputs import parse_dge_table
    wb=openpyxl.Workbook();first=wb.active;first.title='Validated'
    first.append(['gene_id','log2fc']);first.append(['b0005',3])
    second=wb.create_sheet('Executed');second.append(['gene_id','log2fc']);second.append(['b3908',99]);wb.active=1
    out=io.BytesIO();wb.save(out)
    d=create_dataset(uploaded_file=SimpleUploadedFile('multi.xlsx',out.getvalue()),user=users[0])
    preview=preview_expression_rows(d)['rows'][0]['gene_id']
    parsed=parse_dge_table(out.getvalue(),'multi.xlsx').rows[0].gene_id
    assert preview=='b0005' and parsed=='b3908'
    print('XLSX_PREVIEW_VS_EXECUTED',preview,parsed)

def test_first_counts_only_input_validates_then_has_no_engine_rows(users):
    from engine.inputs import parse_dge_table
    raw=b'gene_id,baseMean\nb0005,3\n'
    d=create_dataset(uploaded_file=SimpleUploadedFile('base.csv',raw),user=users[0])
    assert d.is_usable and not parse_dge_table(raw).rows
    print('EXPRESSION_ONLY_UPLOAD_USABLE_ENGINE_ROWS',d.is_usable,0)

def test_queue_publish_failure_leaves_unpublished_queued_run(users, django_capture_on_commit_callbacks):
    with patch('apps.analyses.services._enqueue', side_effect=RuntimeError('queue unavailable')):
        with pytest.raises(RuntimeError,match='queue unavailable'):
            with django_capture_on_commit_callbacks(execute=True):
                run,_=submit_run(user=users[0],input_mode='direct',trigger_sequence='ACGU'*8,idempotency_key='publish-failed')
    run.refresh_from_db();assert run.status=='QUEUED'
    print('QUEUE_PUBLISH_FAILURE_STATUS',run.status)

def test_worker_fatal_exit_leaves_running_then_redelivery_is_noop(users):
    run=make_run(users[0])
    class FatalEngine:
        def run(self,*args):
            raise SystemExit('simulated worker process exit')
    with patch('apps.analyses.services.load_engine', return_value=FatalEngine()):
        with pytest.raises(SystemExit):
            execute_run(str(run.id))
    execute_run(str(run.id));run.refresh_from_db();assert run.status=='RUNNING'
    print('FATAL_EXIT_REDELIVERY_STATUS',run.status)

def test_csrf_foreign_origin_login_is_accepted(users):
    c=Client(enforce_csrf_checks=True)
    response=post(c,'/api/auth/login',{'username':'owner','password':'audit-pass'}, HTTP_ORIGIN='https://foreign.invalid')
    assert response.status_code==200
    print('LOGIN_CSRF_FOREIGN_ORIGIN',response.status_code)

def test_dev_media_endpoint_bypasses_ownership(users):
    d=create_dataset(uploaded_file=SimpleUploadedFile('a.csv',b'gene_id,log2fc\nb0005,3\n'),user=users[0])
    c=Client();response=c.get('/media/'+d.file.name)
    assert response.status_code==200
    print('ANONYMOUS_MEDIA_DOWNLOAD',response.status_code)

def test_missing_zip_file_is_silently_omitted(users):
    import zipfile
    run=make_run(users[0]);a=Artifact(run=run,kind='report',media_type='text/plain',checksum_sha256='')
    a.file.save('gone.txt',ContentFile(b'data'));Path(a.file.path).unlink()
    c=Client();c.force_login(users[0]);response=c.get(f'/api/runs/{run.id}/artifacts/download')
    assert response.status_code==200 and zipfile.ZipFile(io.BytesIO(response.content)).namelist()==[]
    print('MISSING_ZIP_RETURNS_EMPTY_200',response.status_code)

def test_python_client_dry_run_wait_incorrectly_succeeds():
    import sys
    sys.path.insert(0,str(Path('clients/python').resolve()))
    from cernal.job import Job
    job=Job(None, {'job_id':None,'status':None,'candidates':[],'estimate':{'designs':21}})
    assert job.wait() is job
    print('CLIENT_DRY_RUN_WAIT_SUCCESS_NO_JOB',job.job_id)

def test_python_client_does_not_extend_timeout_for_server_wait():
    import sys
    sys.path.insert(0,str(Path('clients/python').resolve()))
    from cernal import Client as SDKClient
    class FakeResponse:
        ok=True
        def json(self): return {'job_id':'test','status':'QUEUED'}
    class RecordingSession:
        def request(self,*args,**kwargs): self.kwargs=kwargs; return FakeResponse()
    s=RecordingSession();c=SDKClient(api_key='audit',base_url='https://example.invalid',session=s)
    c.design(trigger_sequence='ACGU'*8, wait=60)
    assert s.kwargs['timeout']==30 and s.kwargs['params']['wait']==60
    print('CLIENT_WAIT_TIMEOUT',s.kwargs['params']['wait'],s.kwargs['timeout'])

def test_python_client_csv_result_decoded_as_json():
    import sys
    sys.path.insert(0,str(Path('clients/python').resolve()))
    from cernal import Client as SDKClient
    class FakeResponse:
        ok=True
        def json(self): raise ValueError('CSV is not JSON')
    class FakeSession:
        def request(self,*args,**kwargs):return FakeResponse()
    c=SDKClient(api_key='audit',base_url='https://example.invalid',session=FakeSession())
    with pytest.raises(ValueError,match='CSV is not JSON'):
        c.results('job',format='csv')
    print('CLIENT_CSV_RESULTS_JSON_ERROR',True)

def test_nonfinite_numeric_upload_emits_invalid_json_number(users):
    d=create_dataset(uploaded_file=SimpleUploadedFile('bad.csv',b'gene_id,log2fc\nb0005,inf\n'),user=users[0])
    c=Client();c.force_login(users[0]);r=c.get(f'/api/datasets/{d.id}/preview')
    assert d.is_usable and r.status_code==200 and b'Infinity' in r.content
    print('NONFINITE_UPLOAD_PREVIEW',r.content.decode())

def test_admin_forms_allow_mutating_frozen_scientific_inputs(users):
    from django.contrib import admin
    from django.test import RequestFactory
    from apps.datasets.models import Dataset
    a=users[0];a.is_staff=True;a.is_superuser=True;a.save()
    request=RequestFactory().get('/admin/');request.user=a
    run_fields=admin.site._registry[AnalysisRun].get_form(request).base_fields
    dataset_fields=admin.site._registry[Dataset].get_form(request).base_fields
    metric_fields=admin.site._registry[CandidateMetric].get_form(request).base_fields
    assert 'trigger_sequence' in run_fields and 'input_mode' in run_fields
    assert 'file' in dataset_fields and 'validation_status' in dataset_fields
    assert 'raw_value' in metric_fields and 'normalized_value' in metric_fields
    print('EDITABLE_IMMUTABLE_ADMIN',list(run_fields),list(dataset_fields),list(metric_fields))

def test_regenerating_expired_api_key_remains_expired(users):
    from django.utils import timezone
    from apps.accounts.services import regenerate_api_key, authenticate_api_key
    k,secret=issue_api_key(owner=users[0],label='expired',expires_in_days=-1)
    k,new=regenerate_api_key(k)
    assert not k.is_active and authenticate_api_key(new) is None
    print('REGENERATED_EXPIRED_KEY_ACTIVE',k.is_active)
