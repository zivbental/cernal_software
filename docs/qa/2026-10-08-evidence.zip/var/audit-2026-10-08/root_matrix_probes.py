"""Read-only installed-engine/catalog QA; generated artifacts remain in var/audit."""
import dataclasses
import json
import time
from pathlib import Path

from engine.client import LocalEngine
from engine.contract import JobRequest, SCHEMA_VERSION
from engine.domain import Host, DesiredOutcome
from engine.inputs import parse_dge_table
from engine.pipeline import build_tools
from engine.stages.plasmids import BACKBONES
from engine.transcriptome import load_transcriptome, reference_metadata, resolve_gene_id

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
TRIGGER = "AACUUGUUGGCCCAGUGUGAAUCGCUUAAGGGUUAA"
base = JobRequest(
    schema_version=SCHEMA_VERSION, run_id="audit-root", idempotency_key="audit-root",
    input_mode="direct", input_path="", input_checksum="", trigger_sequence=TRIGGER,
    organism="ecoli", params={}, gate_families=["toehold"], scoring_profile="default",
    seed=7, output_dir=str(OUT / "root-matrix"),
)
report = {"payload_runs": [], "backbone_preflights": [], "references": [], "catalog": []}
for host in Host:
    reference = load_transcriptome(host)
    meta = reference_metadata(host)
    report["references"].append({"host": host.value, "genes": len(reference),
        "release": meta.get("release"), "selection_policy": meta.get("selection_policy"),
        "ambiguous_sequences": sum(bool(set(seq) - set("ACGU")) for seq in reference.values())})
    for outcome in DesiredOutcome:
        params = {"payload": {"outputs": [outcome.value]}}
        if outcome is DesiredOutcome.CUSTOM:
            params["payload"]["custom_sequence"] = "ATGGCTTAA"
        name = f"{host.value}-{outcome.value}"
        req = dataclasses.replace(base, organism=host.value, params=params,
            output_dir=str(OUT / "root-matrix" / name))
        start = time.monotonic()
        try:
            result = LocalEngine().run(req, lambda *_: True)
            record = {"host": host.value, "output": outcome.value, "status": result.status,
                "candidates": len(result.candidates), "accepted": len(result.accepted),
                "artifact_kinds": sorted({a.kind for a in result.artifacts}),
                "error": result.error, "warnings": result.warnings,
                "seconds": round(time.monotonic() - start, 3)}
        except Exception as exc:
            record = {"host": host.value, "output": outcome.value, "uncaught": repr(exc)}
        report["payload_runs"].append(record)
        print(json.dumps(record), flush=True)
    for key in [None, *BACKBONES]:
        params = {"backbone": {"catalog_key": key}} if key else {}
        req = dataclasses.replace(base, organism=host.value, params=params)
        try:
            build_tools(req, host)
            record = {"host": host.value, "backbone": key, "accepted_preflight": True}
        except Exception as exc:
            record = {"host": host.value, "backbone": key, "accepted_preflight": False,
                "error": str(exc)}
        report["backbone_preflights"].append(record)

catalog = ROOT / "src/apps/expression/catalog"
manifest = json.loads((catalog / "manifest.json").read_text())
for key, entry in manifest.items():
    path = catalog / entry["csv_path"]
    table = parse_dge_table(path.read_bytes(), path.name)
    host = Host(entry["organism"])
    mapped, missing = [], []
    for row in table.rows:
        try:
            mapped.append(resolve_gene_id(host, row.gene_id))
        except Exception:
            missing.append(row.gene_id)
    record = {"key": key, "host": host.value, "rows": len(table.rows),
        "mapped_rows": len(mapped), "unique_mapped_genes": len(set(mapped)),
        "missing_rows": len(missing), "missing_examples": missing[:5],
        "raw_p_rows": sum(row.p_value is not None for row in table.rows),
        "adjusted_p_rows": sum(row.p_adj is not None for row in table.rows)}
    report["catalog"].append(record)
    print(json.dumps(record), flush=True)
(OUT / "root-matrix-probes.json").write_text(json.dumps(report, indent=2) + "\n")
